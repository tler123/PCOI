#include<bits/stdc++.h>
#define int long long
using namespace std;
signed main(){
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	int q;
	cin>>q;
	while(q--){
		int n;
		cin>>n;
		n--;
		int b=1000000007;
		int ans=1,a=2;
		while(n>0){
			if(n%2==1)ans=ans*a%b;
			a=a*a%b;
			n>>=1;
		}
		cout<<ans;
		if(q>0)cout<<'\n';
	}
}
