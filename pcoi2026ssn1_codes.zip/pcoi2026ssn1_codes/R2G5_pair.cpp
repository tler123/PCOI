#include <bits/stdc++.h>
using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	long long q;
	cin >> q;
	while(q--)
	{
		unordered_map <long long, long long> a;
		set <long long> s;
		long long n, sum = 0;
		cin >> n;
		while(n--)
		{
			long long x;
			cin >> x;
			a[x]++;
			s.insert(x);
		}
		while(!s.empty())
		{
			long long x = *s.rbegin();
			if(a[x] >= 2)
			{
				sum += a[x] * (a[x] - 1) / 2;
			}
			s.erase(x);
		}
		cout << sum << endl;
	}
}
