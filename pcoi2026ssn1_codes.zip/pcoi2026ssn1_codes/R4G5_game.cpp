#include<bits/stdc++.h>
using namespace std;
int main(){
    long long t, k; cin >> t >> k;
    long long res;
    while (t--){
        long long cur = 100;
        printf("? %lld %lld\n", cur, cur);
        cout.flush();
        
        cin >> res;
        if (res == -1) return 0;
        long long count = 1;
        if (res != 1){
            while (count+1 <= k){
                cur--;
                printf("? %lld %lld\n", cur, cur);
                
                cin >> res;
                if (res == -1) return 0;
                if (res) break;
                
                count++;
            }
        } else {
            printf("? %lld %lld\n", 99, 99);
            cout.flush();
            
            cin >> res;
            if (res == -1) return 0;
            if (res == 1) cur = 0;
            else cur = 100;
        }
        
        if (count == 100 && res == 0) cur = 0;
        printf("! %lld\n", cur);
        cout.flush();
        
    }
}