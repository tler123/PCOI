#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int T;
    cin >> T;

    while (T--) {
        int n;
        cin >> n;

        vector<int> a(n);
        for (int i = 0; i < n; i++) {
            cin >> a[i];
        }

        sort(a.begin(), a.end());

        long long ans = 0;

        int i = 0;
        while (i < n) {
            int j = i;
            while (j < n && a[j] == a[i]) {
                j++;
            }

            long long cnt = j - i;
            ans += cnt * (cnt - 1) / 2;

            i = j;
        }

        cout << ans << '\n';
    }

    return 0;
}