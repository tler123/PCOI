#include<bits/stdc++.h>
using namespace std;

long long MOD = 1e9 + 7; 

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	vector <long long> a(1000010);
	a[1] = 1;
	for (int i = 2; i <= 1000000; i++)
	{
		a[i] = a[i - 1] * 2LL % MOD; 
	}
	long long q;
	cin >> q; 
	while(q--)	
	{
		long long n;
		cin >> n;
		cout << a[n] << endl;
	}
	return 0;
}
