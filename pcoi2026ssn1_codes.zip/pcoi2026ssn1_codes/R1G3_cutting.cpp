#include <bits/stdc++.h>
using namespace std;

int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long j, t;
    cin >> j;
    for (long long i = 1; i <= j; ++i){
        long long n = 1;
        cin >> t;
        for (long long u = 1; u <= t - 1; ++u){
            n *= 2;
        }
        cout << n % (1000000000 + 7)<< endl;
    }
}