#include <bits/stdc++.h>
using namespace std;
int main() {
    int q;
    cin >> q;
    while (q--) {
        int n;
        cin >> n;
        vector <int> a(n);
        for (int i = 0; i < n; i++) {
            cin >> a[i];
        }
        sort(a.begin(), a.end());
        long long ans = 0, b = 1;
        for (int i = 1; i < n; i++) {
            if (a[i] == a[i - 1]) {
                ans += b;
                b++;
            } else {
                b = 1;
            }
        }
        cout << ans << endl;
    }
}
