#include<bits/stdc++.h>
using namespace std;
#define int long long
signed main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	
	int k = 0;
	
	int n;
	cin >> n;
	pair<int,int> a[n+10] = {};
	int dp[n+10] = {};
	for (int i = 1; i <= n; i++)
	{
		cin >> a[i].first >> a[i].second;
		dp[i] = a[i].second;
		k = max(k, a[i].second);
	}
	
	vector<int> prime(k * 2 + 1, 1);
	
	prime[1] = 0;
	
	for (int i = 2; i < prime.size(); i++){
		if (prime[i] == 1){
			for (int j = i * i; j < prime.size(); j += i){
				prime[j] = 0;
			}
		}
	}
	
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j < i; j++){/*
			bool w = true;
			for (int k = 2; k * k <= a[i].second+a[j].second; k++)
			{
				if ((a[i].second+a[j].second) % k == 0)
				{
					w = false;
					break;
				}
			}*/
				if (a[i].first != a[j].first && prime[a[i].second+a[j].second])
				{
					dp[i] = max(dp[i],dp[j]+a[i].second);
					//cout << "test " << a[i].second+a[j].second << endl;
				}
			}
	}
	int mx = 0;
	for (int i = 1; i <= n; i++)
	{
		mx = max(mx,dp[i]);
	}
	cout << mx;
    return 0;
}
