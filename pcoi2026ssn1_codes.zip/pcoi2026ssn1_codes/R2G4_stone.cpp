#include <bits/stdc++.h>
using namespace std;
bool isprime(int n){
	if(n<=1) return 0;
	for(int i=2;i*i<=n;i++){
		if(n%i==0) return 0;
	}
	return 1;
}
int main(){
	int prime[800010]={0},cntprime[800010]={0},x=2;
	prime[1] = 2;
	cntprime[1] = 1;
	for(int i=3;i<=800000;i++){
		if(isprime(i)){
			int cnt=0;
			int a=i;
			while(isprime(a)){
				a--;
				cnt++;
				for(int j=1;j<x;j++){
					while(a%prime[j]==0){
						a/=prime[j];
						cnt+=cntprime[j];
					}
					if(a==1) break;
				}
			}
			prime[x] = i;
			cntprime[x] = cnt;
			x++;
		}
	}
	int n;
	int ans=0;
	cin>>n;
	for(int i=1;i<=x;i++){
		while(n%prime[i]==0){
			n/=prime[i];
			ans+=cntprime[i];
		}
		if(n==1) break;
	}
	while(isprime(n)){
		n--;
		ans++;
		for(int i=1;i<=x;i++){
			while(n%prime[i]==0){
				n/=prime[i];
				ans+=cntprime[i];
			}
			if(n==1) break;
		}
	}
	cout<<ans<<'\n';
}
/*
--------------------------------------------------------------
|                                                            |
|  ---------             ---      	    |--|  /-/            |        
| |         |           /   \           |  | / /             |
|  --|   |--           / ___ \          |   / /              |
|    |   |            / /___\ \         |   \  \             |
|    |   |           /         \        |  | \  \            |
|    | _ |          /__/-----\__\       |--|  \--\           |
|                                                            |
|    |----|      |---\  |-|          hi!!!                   |           
|     |  |       | |\ \ | |          I AM    				 |        
|     |  |       | | \ \| |          PC | MORTIS             |        
|    |----|      |-|  \-\-|          PCMS_LEITAKIN           |       
--------------------------------------------------------------
if you delete it(^), you are copying other's code
*/
