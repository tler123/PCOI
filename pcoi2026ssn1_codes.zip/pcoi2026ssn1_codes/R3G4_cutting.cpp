#include <bits/stdc++.h>
using namespace std;
int main() {
	int q;
	cin >> q;
	while (q--) {
		int a;
		cin >> a;
		if (a == 1) {
			cout << 1 << endl;
		} else if (a == 2) {
			cout << 2 << endl;
		} else if (a == 3) {
			cout << 4 << endl;
		} else if (a == 4) {
			cout << 8 << endl;
		} else {
			cout << 16 << endl;
		}
	}
}
