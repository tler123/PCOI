#include <iostream>
using namespace std;
int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    cin >> n;
    int a[n], b[n]; 
    for (int i = 0; i < n; i++){
        cin >> b[i];
        int x = b[i];
        a[i] = (x*x*x*x - 6*x*x*x + 23*x*x - 18*x + 24) / 24;
    }
    for (int i = 0; i < n; i++){
        cout << a[i] << endl;
    }
    return 0;
}