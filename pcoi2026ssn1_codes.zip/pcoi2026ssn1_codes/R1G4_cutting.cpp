#include <bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    
    long long int t; cin >> t;
    while (t--)
    {
        long long int a;
        cin >> a;
        long long int oa = a;
        if (a == 1)
        {
            cout << 1 << "\n";
        }
        else if (a == 2)
        {
            cout << 2 << "\n";
        }
        else
        {
            long long int ans = a - 2;
            while (ans >= 1000000007)
            {
                ans -= 1000000007;
            }
            while (a >= 1000000007)
            {
                a -= 1000000007;
            }
            ans *= a;
            if (oa % 2 != 0) ans++;
            while (ans >= 1000000007)
            {
                ans -= 1000000007;
            }
            cout << ans << "\n";
        }
    }
    return 0;
}
