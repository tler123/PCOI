#include <bits/stdc++.h>
using namespace std;

const long long MOD = 1000000007LL;
const long long INV2 = 500000004LL;
const long long INV24 = 41666667LL;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int T;
    cin >> T;

    while (T--) {
        long long n;
        cin >> n;

        long long x = n % MOD;

      
        long long comb2 = x;
        comb2 = comb2 * ((x - 1 + MOD) % MOD) % MOD;
        comb2 = comb2 * INV2 % MOD;

     
        long long comb4 = x;
        comb4 = comb4 * ((x - 1 + MOD) % MOD) % MOD;
        comb4 = comb4 * ((x - 2 + MOD) % MOD) % MOD;
        comb4 = comb4 * ((x - 3 + MOD) % MOD) % MOD;
        comb4 = comb4 * INV24 % MOD;

       
        long long ans = (1 + comb2 + comb4) % MOD;

        cout << ans << '\n';
    }

    return 0;
}