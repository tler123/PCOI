#include<bits/stdc++.h>
using namespace std;
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long T,n;
    cin>>T;
    while (T--){
        long long c = 0;
        cin>>n;
        long long a[n];
        for (long long m=0; m<n; m++){
            cin>>a[m];
        }
        for (long long i=0; i<n; i++){
            for (long long j=i+1; j<=n; j++){
                if (a[i]==a[j]) c++;
            } 
        }
        cout << c << endl;
    }
}