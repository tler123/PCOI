#include <bits/stdc++.h>
using namespace std;
int main() {
	int t;
	cin >> t;
	while (t--) {
		int i;
		cin >> i;
		/*if (i == 1) {
			cout << 1 << '\n';
		}
		else if (i == 2) {
			cout << 2 << '\n';
		}
		else if (i == 3) {
			cout << 4 << '\n';
		}
		else if (i == 4) {
			cout << 8 << '\n';
		}*/
		cout << pow(2, i - 1) << '\n';
	}
	return 0;
}
