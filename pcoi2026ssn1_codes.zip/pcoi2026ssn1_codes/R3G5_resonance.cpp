#include<bits/stdc++.h>
using namespace std;
long long int c[10005]={0},p[10005]={0},f[10005]={0};
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	long long int ans=0,n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>c[i]>>p[i];
	}
	for(int i=1;i<=n;i++){
		f[i]=p[i];
		for(int j=1;j<i;j++){
			if(c[j]!=c[i]){
				long long int s=p[j]+p[i];
				bool ojbk=true;
				if(s<2){
					ojbk=false;					
				}
				for(int k=2;k*k<=s;k++){
					if(s%k==0){
						ojbk=false;
					}
				}
				if(ojbk){
					if(f[j]+p[i]>f[i]){
						f[i]=f[j]+p[i];
					}
				}
			}
		}
	}
	for(int i=1;i<=n;i++){
		if(f[i]>ans){
			ans=f[i];
		}
	}
	cout<<ans<<endl;
	return 0;
}
