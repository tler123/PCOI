#include<bits/stdc++.h>
using namespace std;
int main(){
	int t;

	cin>>t;
	while(t--){
		long long a[500010],n;
		cin>>n;
		for(int i=1;i<=n;i++) cin>>a[i];
		sort(a+1,a+1+n);
		long long cnt=1,ans=0;
		for(int i=2;i<=n;i++){
			if(a[i]==a[i-1]) cnt++;
			else{
				ans+=(cnt*(cnt-1)/2);
				cnt = 1;
			}
		}
		cout<<ans+(cnt*(cnt-1)/2)<<'\n';
	}
	return 0;
}
