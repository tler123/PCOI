#include<bits/stdc++.h>
using namespace std;
int main(){
    cin.tie(0), cout.tie(0);
    ios_base::sync_with_stdio(0);
    
    string s; cin >> s;
    stack<char> a;
    queue<char> b;
    for (long long i = 0; i < s.size(); i++){
        char cur = s[i];
        if (cur==')'){
            char x;
            while (a.top() != '('){
                b.push(a.top());
                a.pop();
            }
            
            a.pop();
            
            while (!b.empty()){
                a.push(b.front());
                b.pop();
            }
        } else a.push(cur);
    }
    
    string res = "";
    while (!a.empty()){
        res = a.top() + res;
        a.pop();
    }
    
    printf("%s", res.c_str());
}