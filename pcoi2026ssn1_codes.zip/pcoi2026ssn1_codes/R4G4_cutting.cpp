#include <bits/stdc++.h>
#define mod 1000000007
#define int long long
using namespace std;


int quickpow (int a, int b, int p) {
	if (b == 0) return 1;
	if (b == 1) return a;
	if (b % 2 == 1) return a * quickpow(a, b - 1, p) % mod;
	int half = quickpow(a, b / 2, p);
	return (half % mod * half % mod) % mod;
}
signed main () {
	ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
	
	int t;
		
	cin >> t;
	
	for (int i = 0; i < t; i++){
		int n;
		cin >> n;
		
		if (n == 1) cout << 1 << "\n";
		else if (n == 2) cout << 2 << "\n";
		else if (n == 3) cout << 4 << "\n";
		else if (n == 4) cout << 8 << "\n";
		else if (n == 5) cout << 16 << "\n"; 
		else if (n % 2 == 0) cout << (quickpow(2, n / 2 - 1, mod) % mod * n % mod) % mod<< "\n";
		else cout << ((n - 1) % mod * (n - 1) % mod) % mod << "\n";
	}
}