#include <bits/stdc++.h>
using namespace std;

struct record{
	int color;
	long long energy;
};

bool compare(int x, int y){
	return x>y;
}

const int MAX_SUM=2000005;
vector<bool> isPrime(MAX_SUM,true);
void primelst(){
    isPrime[0]=isPrime[1]=false;
    for(int i=2;i*i<MAX_SUM;i++){
        if(isPrime[i]){
            for (int j=i*i;j<MAX_SUM;j+=i) {
                isPrime[j]=false;
            }
        }
    }
}


int main() {
    primelst();
    int n;
    cin>>n;
    
    vector<record> a;
    for(int i=0;i<n;i++){
		record z;
		cin>>z.color;
		cin>>z.energy;
		a.push_back(z);
	}
    
    vector<long long> dp(n,0);
    long long maxsum=0;
    for (int i=0;i<n;i++){
        dp[i]=a[i].energy;
        for(int j=0;j<i;j++){
            if(a[i].color!=a[j].color and isPrime[a[i].energy+a[j].energy]){
                if(dp[j]+a[i].energy>dp[i]){
                    dp[i]=dp[j]+a[i].energy;
                }
            }
        }
	
        if(dp[i]>maxsum){
            maxsum=dp[i];
        }
    }
    cout<<maxsum<<endl;
    return 0;
}
