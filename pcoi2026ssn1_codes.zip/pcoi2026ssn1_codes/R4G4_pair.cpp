#include<bits/stdc++.h>
using namespace std;
#define int long long
signed main() {
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int t,n;
	cin >> t;
	for (; t--; )
	{
		cin >> n;
		int a[n+10] = {};
		unordered_map <int,int> mp;
		for (int i = 1; i <= n; i++)
		{
			cin >> a[i];
			if (mp.find(a[i]) == mp.end())
			{
				mp[a[i]] = 1;
			}
			else
			{
				mp[a[i]]++;
			}
		}
		int ret = 0;
		for (auto y : mp)
		{
			ret += (y.second * (y.second-1)) / 2;
		}
		cout << ret << "\n";
	}
    return 0;
}
