#include <bits/stdc++.h>
using namespace std;
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t,a[10005]={0};
    cin>>t;
    a[1]=1;
    a[2]=2;
    a[3]=4;
    a[4]=8;
    a[5]=16;
    for(int i=6;i<=10000;i++){
        a[i]=a[i-1]+a[i-2]+a[i-3]+a[i-5];
        a[i]%=1000000007;
    }
    for(int i=1;i<=t;i++){
        int n;
        cin>>n;
        cout<<a[n]<<endl;
    }
    return 0;
}
