#include<bits/stdc++.h>
using namespace std;
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    long long int q,n;
    cin>>q;
    while(q--){
    	cin>>n;
    	if(n==1){
    		cout<<1<<endl;
		}else if(n==2){
			cout<<2<<endl;
		}else if(n==3){
			cout<<4<<endl;
		}else if(n==4){
			cout<<8<<endl;
		}else{
			cout<<16<<endl; 
		}
	}
    return 0;
}
