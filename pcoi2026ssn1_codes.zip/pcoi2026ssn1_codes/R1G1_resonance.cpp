#include <iostream>
#include <vector>
using namespace std;

int main() {
    int n;
    cin>>n;

    vector<int> c(n), p(n);
    int MP=0;

    for (int i=0;i<n;i++) {
        cin>>c[i]>>p[i];
        MP=max(MP,p[i]);
    }

    int MSUM=MP*2;

    vector<bool> prime(MSUM+1,true);
    prime[0]=false;
    prime[1]=false;

    for (int i=2;i*i<=MSUM;i++) {
        if (prime[i]) {
            for (int j=i*i;j<=MSUM;j+=i) {
                prime[j]=false;
            }
        }
    }

    vector<long long> dp(n, 0);
    long long ans = 0;

    for (int i=0;i<n;i++) {
        dp[i]=p[i];

        for (int j=0;j<i;j++) {
            if (c[i]==c[j]) continue;

            int sum=p[i]+p[j];

            if (prime[sum]) {
                dp[i]=max(dp[i], dp[j] + p[i]);
            }
        }

        ans=max(ans,dp[i]);
    }

    cout<<ans<<endl;
    return 0;
}