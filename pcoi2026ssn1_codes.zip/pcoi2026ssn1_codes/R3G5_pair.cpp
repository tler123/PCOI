#include<bits/stdc++.h>
using namespace std;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int q,n;
	cin>>q;
	for(int i=0;i<q;i++){
		cin>>n;
		long long int a[200005]={0},ans=0,xx=1;
		for(int j=0;j<n;j++){
			cin>>a[j];
		}
		sort(a,a+n);
		for(int j=1;j<n;j++){
			if(a[j]==a[j-1]){
				xx++;
			}else{
				ans=ans+xx*(xx-1)/2;
				xx=1;
			}
		}
		ans=ans+xx*(xx-1)/2;
		cout<<ans<<endl;
	}
	return 0;
}
