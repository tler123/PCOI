#include<bits/stdc++.h>
using namespace std;
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	string s;
	cin>>s;
	int n=s.length();
	vector<string> vs(n);
	int now=0;
	for(int i=0;i<n;i++){
		char c=s[i];
		if(c=='('){
			now++;
		}
		else if(c==')'){
			if(now&1){
				vs[now-1]+=vs[now];
			}
			else{
				vs[now-1]=vs[now]+vs[now-1];
			}
			vs[now]="";
			now--;
		}
		else{
			if(now&1){
				vs[now]=c+vs[now];
			}
			else vs[now]+=c;
		}
	}
	cout<<vs[0];
}
