#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import sys

def solve():
    s = sys.stdin.read().strip()
    if not s:
        return
    
    n = len(s)
    pair = [0] * n
    st = []
    
    for i, c in enumerate(s):
        if c == '(':
            st.append(i)
        elif c == ')':
            j = st.pop()
            pair[i], pair[j] = j, i
            
    res = []
    i, d = 0, 1
    while i < n:
        if s[i] in '()':
            i = pair[i]
            d = -d
        else:
            res.append(s[i])
        i += d
        
    print(''.join(res))

if __name__ == '__main__':
    solve()

