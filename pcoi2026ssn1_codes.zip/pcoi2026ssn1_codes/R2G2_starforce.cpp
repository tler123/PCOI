#include <bits/stdc++.h>
using namespace std;

int main(){
    string s;
    if(!(cin>>s)) return 0;

    int n=s.length();
    vector<int> match(n, -1);
    stack<int> st;

    for(int i=0;i<n;i++){
        if(s[i]=='('){
            st.push(i);
        }else if(s[i]==')'){
            int left=st.top();
            st.pop();
            match[left]=i;
            match[i]=left;
        }
    }

    string result="";
    int curr=0;
    int dir=1;
    while(curr>=0 and curr<n){
        if(s[curr]=='(' or s[curr]==')'){
            curr=match[curr];
            dir=-dir;
        }else{
            result+=s[curr];
        }
        curr+=dir;
    }

    cout<<result<<endl;
    return 0;
}