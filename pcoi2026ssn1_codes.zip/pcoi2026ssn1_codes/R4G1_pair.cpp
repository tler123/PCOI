#include <bits/stdc++.h>
#define int long long
using namespace std;

void solve() {
    int n,ans=0,cnt=0;
    cin >> n;
    vector<int>a(n);
    for (int i = 0; i < n; i++) 
	{
        cin >> a[i];
    }
    
    sort(a.begin(),a.end());
    for(int i=1;i<n;i++){
    	if(a[i]==a[i-1]){
    		cnt++;
		}
		else cnt=0;
    	ans+=cnt;
	}
    
    cout << ans << endl;
}

signed main() {
    
    int T;
    cin >> T;
    while (T--) 
	{
        solve();
    }
    
    return 0;
}
