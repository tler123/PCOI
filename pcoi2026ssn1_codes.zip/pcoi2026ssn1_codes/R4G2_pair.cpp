#include<bits/stdc++.h>
using namespace std;
int main(){
	int T;cin>>T;
	while(T--){
		int n,cnt=0;cin>>n;
		vector<int>a(n,0),b(n,0);
		for(int i=0;i<n;i++){
			int c;
			cin>>c;
			bool tf=true;
			for(int j=0;j<cnt;j++){
				if(b[j]==c){
					tf=false;
					a[j]++;
				}
			}
			if(tf){
				b[cnt]=c;
				a[cnt++]++;
			}
		}
		long long ans=0;
		for(int i=0;i<cnt;i++){
			ans+=(a[i]-1)*a[i]/2;
		}
		cout<<ans<<'\n';
	}
	return 0;
}
