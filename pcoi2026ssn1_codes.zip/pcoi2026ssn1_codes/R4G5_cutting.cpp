#include<bits/stdc++.h>
#define LL long long
using namespace std;

LL T, n; 
LL mod = 1000000007; 

LL q_pow(LL a, LL b) {
    if (b == 0) return 1; 
    if (b % 2) {
        LL t = q_pow(a, b / 2); 
        return (t * t % mod) * a % mod; 
    } else {
        LL t = q_pow(a, b / 2); 
        return (t * t % mod); 
    }
}

int main() { 
    cin >> T; 
    for (LL i = 1; i <= T; i++) {
        cin >> n; 
        cout << (q_pow(2, n - 1) + mod) % mod << "\n"; 
    }
    return 0; 
}