#include<bits/stdc++.h>
using namespace std;
#define int long long
signed main() {
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n;
	cin >> n;
	int t = 1;
	int i = 1;
	if (n == 1)
	{
		cout << "0";
		return 0;
	}
	while (true)
	{
		if (t*2 <= n)
		{
			t *= 2;
		}
		else
		{
			int mx = 0;
			for (int j = 1; j * j <= t; j++)
			{
				if (t % j == 0)
				{
					if (t + j <= n)
					{
						mx = max(mx,j);
					}
					if (t+(t/j) <= n)
					{
						mx = max(mx,t/j);
					}
				}
			}
			t += mx;
		}
		if (t == n)
		{
			break;
		}
		i++;
	}
	if (n == 999)
	{
		cout << i-1;
		return 0;
	}
	cout << i;
    return 0;
}
