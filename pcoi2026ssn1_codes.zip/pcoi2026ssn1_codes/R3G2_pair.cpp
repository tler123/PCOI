#include <iostream>
using namespace std;
int main(){
    long long int n,m,count[n];
    cin>>n;
    for (long long int i = 0 ; i < n ; i ++){
        count[i]=0;
        cin>>m;
        long long int x[m];
        for (long long int j = 0 ; j < m ; j ++){
            cin>>x[j];
        }
        for (long long int j = 0 ; j < m ; j ++){
            for (long long int k = j+1 ; k < m ; k ++){
                if (x[j] == x[k]){
                    count[i]++;
                }
            }
        }
    }
    for (long long int i = 0 ; i < n ; i ++){
        cout<<count[i]<<endl;
    }
    
}