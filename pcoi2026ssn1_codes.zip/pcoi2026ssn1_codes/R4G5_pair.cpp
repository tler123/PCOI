#include<bits/stdc++.h>
#define LL long long
using namespace std;

map<int, int> mp; 
LL T, n, k; 

int main() {
    cin >> T; 
    while (T--) {
        LL ans = 0; 
        mp.clear(); 
        cin >> n; 
        for (LL i = 1; i <= n; i++) {
            cin >> k; 
            if (mp.count(k)) mp[k]++; 
            else mp[k] = 1; 
        } 
        for (auto x = mp.begin(); x != mp.end(); x++) {
            LL d = x->second; 
            ans += d * (d - 1) / 2; 
        }
        cout << ans << "\n"; 
    }
    return 0; 
}