#include<bits/stdc++.h>
using namespace std;
int xx[1005]={0};
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n;
	cin>>n;
	for(int i=2;i<=n;i++){
		xx[i]=1000000000;
	}
	for(int i=1;i<n;i++){
		if(xx[i]==1000000000){
			continue;
		}
		for(int j=1;j<=i;j++){
			if(i%j==0){
				int ng=i+j;
				if(ng<=n){
					if(xx[i]+1<xx[ng]){
						xx[ng]=xx[i]+1;
					}
				}
			}
		}
	}
	cout<<xx[n]<<endl;
	return 0;
}
