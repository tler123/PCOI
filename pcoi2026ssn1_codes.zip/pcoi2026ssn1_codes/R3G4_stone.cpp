#include <bits/stdc++.h>
using namespace std;
int main() {
    int n;
    cin >> n;
    vector<int> ans(n + 1, 1e9);
    ans[1] = 0;
    for (int i = 1; i < n; i++) {
        for (int j = 1; j <= i; j++) {
            if (i % j == 0 && i + j <= n) {
                ans[i + j] = min(ans[i + j], ans[i] + 1);
            }
        }
    }
    cout << ans[n];
}
