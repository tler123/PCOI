#include<bits/stdc++.h>
#define LL long long
using namespace std;

struct cell {
    LL d, st; 
    bool operator()(cell u, cell v) {
        return u.st > v.st; 
    }
}; 
LL n, d, lg; 
LL vis[1000005]; 
priority_queue<cell, vector<cell>, cell> pq; 

void bfs() {
    vis[1] = 0; 
    pq.push({1, 0}); 
    while (pq.size()) {
        cell e = pq.top(); pq.pop(); 
        for (LL i = 1; i * i <= e.d; i++) {
            if (e.d % i == 0) {
                for (LL j = 1; j <= 2; j++) {
                    if (j == 1) {
                        LL nd = e.d / i + e.d; 
                        if (nd > n) continue; 
                        if (vis[nd] > 0 && vis[nd] <= e.st + 1) continue; 
                        vis[nd] = e.st + 1; 
                        pq.push({nd, e.st + 1}); 
                    } else {
                        LL nd = i + e.d; 
                        if (nd > n) continue; 
                        if (vis[nd] > 0 && vis[nd] <= e.st + 1) continue; 
                        vis[nd] = e.st + 1; 
                        pq.push({nd, e.st + 1}); 
                    }
                }
            }
        }
    }
}

int main() {
    /*
    cin >> n; 
    lg = log2(n); 
    d = pow(2, lg); 
    
    LL w = n - d; 
    LL cnt = 0; 
    for (int i = 0; i < 25; i++) {
        if ((w & (1 << i)) > 0) cnt++; 
    }
    cout << lg + cnt; 
    */
    memset(vis, -1, sizeof(vis)); 
    cin >> n; 
    bfs(); 
    cout << vis[n]; 
    return 0; 
}
