#include<bits/stdc++.h>
using namespace std;
int turn2(long long n){
	if(n<=0)return 1;
	if(n==1)return 2;
	int mod=1000000007;
	long long ans=turn2(n/2)%mod;
	ans=ans*ans%mod;
	ans=ans*turn2(n%2)%mod;
	return ans%mod;
}
int main(){
	int T;cin>>T;
	while(T--){
		long long n;cin>>n;
		cout<<turn2(n)/2<<'\n';
	}
	return 0;
}
