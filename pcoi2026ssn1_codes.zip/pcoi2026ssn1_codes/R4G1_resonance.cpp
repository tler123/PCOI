#include <bits/stdc++.h>

using namespace std;

const int MAX_P = 2000000;
vector<bool> is_prime(MAX_P + 1, true);

void check() 
{
    is_prime[0] = is_prime[1] = false;
    for (int p = 2; p * p <= MAX_P; p++) 
	{
        if (is_prime[p]) 
		{
            for (int i = p * p; i <= MAX_P; i += p)
            {
            	is_prime[i] = false;	
			}            
        }
    }
}

struct Cat {
    int c;
    long long p;
};

int main() {
    check();
    int n;
    cin >> n;
    vector<Cat> cats(n);
    for (int i = 0; i < n; i++) 
	{
        cin >> cats[i].c >> cats[i].p;
    }

    vector<long long> dp(n, 0);
    long long max_energy = 0;

    for (int i = 0; i < n; i++) 
	{
        dp[i] = cats[i].p;
        for (int j = 0; j < i; j++) 
		{
            if (cats[i].c != cats[j].c && is_prime[cats[i].p + cats[j].p]) 
			{
                dp[i] = max(dp[i], dp[j] + cats[i].p);
            }
        }
        max_energy = max(max_energy,dp[i]);
    }

    cout << max_energy << endl;

    return 0;
}
