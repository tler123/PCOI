#include <bits/stdc++.h>
using namespace std;
#define int long long
signed main()
{
    int t;
    cin>>t;
    for(int i=1;i<=t;i++){
        int n,ans=0;
        map<int,int>mp;
        cin>>n;
        for(int i=1;i<=n;i++){
            int x;
            cin>>x;
            ans+=mp[x];
            mp[x]++;
        }
        cout<<ans<<endl;
    }
    return 0;
}