#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin>>t;
    while(t--){
    	int n;
	    cin>>n;
	    
	    map<int, long long> sum;
	    for(int i=0;i<n;i++){
	        int x;
	        cin>>x;
	        sum[x]++; 
	    }
	    
	    long long ans=0;
	    for (auto const& [num,count]:sum) {
	        ans+=count*(count-1)/2;
	    }
	    
	    cout<<ans<<endl;
	}
    return 0;
}