#include<bits/stdc++.h>
#define int long long
using namespace std;
signed main(){
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	string s;
	cin>>s;
	for(int i=0;i<s.size();i++){
		if(s[i]=='('){
			int a=i;
			while(s[i]!=')'){
				i++;
			}
			int b=i;
			for(i=i-1;i>a;i--){
				cout<<s[i];
			}
			i=b;
		}
		else cout<<s[i];
	}
}
