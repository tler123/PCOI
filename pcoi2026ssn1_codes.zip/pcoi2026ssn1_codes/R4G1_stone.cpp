#include <bits/stdc++.h>
using namespace std;
struct Node
{
	int x;
	int step;
};
bool visited[1000005];
queue<Node> q;
int bfs(int n)
{
	if(n == 1)
	{
		return 0;
	}
	q.push({1,0});
	visited[1] = true;
	while(!q.empty())
	{
		Node cur = q.front();
		q.pop();
		if(cur.x == n)
		{
			return cur.step;
		}
		for(int i = 1; i * i <= cur.x; i++)
		{
			if(cur.x % i == 0)
			{
				int v1 = cur.x + i;
				if(v1 <= n && visited[v1] == false)
				{
					visited[v1] = true;
					q.push({v1, cur.step + 1});
				}
				
				int v2 = cur.x + (cur.x/i);
				if(v2 <= n && visited[v2] == false)
				{
					visited[v2] = true;
					q.push({v2, cur.step + 1});
				}
			}
		}
	}
	return -1;
}
int main()
{
	int n;
	cin >> n;
	cout << bfs(n);
	return 0;
}
