#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import sys

c=10**9+7
def solve():
    a=sys.stdin.read().split()
    if not a:
        return
    
    T = int(a[0])
    results = []
    inv24 = pow(24, c-2, c)
    
    for i in range(1, T+1):
        n = int(a[i])
        c2 = (n%c) * ((n-1)%c)%c*pow(2,c-2,c)%c
        c4 = (n%c) * ((n-1)%c) % c*((n-2)%c)%c* ((n-3)%c)%c * inv24%c
        
        ans = (1+c2+c4)%c
        results.append(str(ans))
        
    print('\n'.join(results))

if __name__ == '__main__':
    solve()

