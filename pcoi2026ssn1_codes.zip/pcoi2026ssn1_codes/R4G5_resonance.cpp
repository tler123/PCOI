#include<bits/stdc++.h>
using namespace std;

struct Cat{
    long long c, p;
};

bool isPrime(long long x){
    if (x < 2) return false;
    for (long long i = 2; i*i<=x; i++){
        if (x % i == 0) return false;
    }
    return true;
}

int main(){
    cin.tie(0), cout.tie(0);
    ios_base::sync_with_stdio(0);
    
    long long n; cin >> n;
    vector<Cat> meow(n+1, {0, 0});
    for (long long i = 1; i <= n; i++) cin >> meow[i].c >> meow[i].p;
    
    vector<long long> dp(n+1, 0);
    for (long long i = 1; i <= n; i++){
        dp[i] = meow[i].p;
        for (long long j = 1; j < i; j++){
            if (meow[i].c != meow[j].c && isPrime(meow[i].p+meow[j].p)){
                dp[i] = max(dp[i], dp[j] + meow[i].p);
            }
        }
    }
    
    long long fres = 0;
    for (long long x : dp) fres = max(fres, x);
    printf("%d", fres);
}