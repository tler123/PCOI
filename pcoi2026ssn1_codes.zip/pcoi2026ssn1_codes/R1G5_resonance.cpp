#include <bits/stdc++.h>
using namespace std;

const int MAXN = 10005;
const int MAXSUM = 2000005;

int c[MAXN];
int p[MAXN];
long long dp[MAXN];
char isPrime[MAXSUM];

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;

    int maxP = 0;
    for (int i = 0; i < n; i++) {
        cin >> c[i] >> p[i];
        if (p[i] > maxP) maxP = p[i];
    }

    int maxSum = 2 * maxP;

   
    memset(isPrime, 1, sizeof(isPrime));
    isPrime[0] = isPrime[1] = 0;

    for (int i = 2; i * i <= maxSum; i++) {
        if (isPrime[i]) {
            for (int j = i * i; j <= maxSum; j += i) {
                isPrime[j] = 0;
            }
        }
    }

    long long answer = 0;

   
    for (int i = 0; i < n; i++) {
        dp[i] = p[i];

        for (int j = 0; j < i; j++) {
            if (c[j] != c[i] && isPrime[p[j] + p[i]]) {
                long long cand = dp[j] + p[i];
                if (cand > dp[i]) dp[i] = cand;
            }
        }

        if (dp[i] > answer) answer = dp[i];
    }

    cout << answer << '\n';

    return 0;
}