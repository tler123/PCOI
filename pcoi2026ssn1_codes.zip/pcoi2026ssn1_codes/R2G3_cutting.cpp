#include<bits/stdc++.h>
using namespace std;

int main() {
	int t;
	scanf("%d",&t);
	for(int i=0;i<t;i++){
		int n;
		scanf("%d",&n);
		if(n==1){
			printf("1");
		}else if(n==2){
			printf("2");
		}else if(n==3){
			printf("4");
		}else if(n==4){
			printf("8");
		}else if(n==5){
			printf("16");
		}
		printf("\n");
	}
}
