#include<bits/stdc++.h>
using namespace std;

int number[500010];

int main() {
	int t;
	scanf("%d",&t);
	for(int i=0;i<t;i++){
		int n;
		scanf("%d",&n);
		for(int j=0;j<n;j++){
			scanf("%d",&number[j]);
		}
		sort(number,number+n);
		int abc=0,cnt=0,ans=0;
		for(int j=0;j<n;j++){
			if(number[j]!=abc){
				for(int k=1;k<cnt;k++){
					ans+=k;
				} 
//				printf("cnt=%d|abc=%d|ans=%d\n",cnt,abc,ans);
				cnt=1,abc=number[j];
			}else{
				cnt++;
			}
//			printf("abc=%d\n",abc);
		}
		if(cnt>1){
			for(int k=1;k<cnt;k++){
				ans+=k;
			} 
		}
		printf("%d\n",ans);
	}
} 
