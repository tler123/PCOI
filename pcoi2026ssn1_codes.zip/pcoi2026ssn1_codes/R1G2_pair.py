#!/usr/bin/env python
# coding: utf-8

# In[3]:


import sys
from collections import Counter
a = sys.stdin.read().split()
if a:
    it = iter(a)
    T = int(next(it))
    for _ in range(T):
        n = int(next(it))
        b = Counter(next(it) for _ in range(n))
        print(sum(c*(c-1)//2 for c in b.values()))


# In[ ]:




