#include<bits/stdc++.h>
using namespace std;
string st[200005];
int main(){ 
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	string s,cur="";
	cin>>s;
	int kenneth=0;
	for(int i=0;i<int(s.size());i++){
		char ch=s[i];
		if(ch=='('){
			st[kenneth]=cur;
			kenneth++;
			cur="";
		}else if(ch==')'){
			string xx="";
			for(int j=int(cur.size())-1;j>=0;j--){
				xx+=cur[j];
			}
			cur=st[kenneth-1]+xx;
			kenneth--;
		}else{
			cur+=ch;
		}
	}
	cout<<cur<<endl;
	return 0;
}
