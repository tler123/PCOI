#include <bits/stdc++.h>
using namespace std;
int main() {
    int n;
    cin >> n;
    vector <int> a(n);
    vector <long long> b(n), c(n);
    long long ans = 0;
    for (int i = 0; i < n; i++) {
        cin >> a[i] >> b[i];
        long long mx = 0;
        for (int j = 0; j < i; j++) {
            if (a[i] != a[j]) {
                long long sum = b[i] + b[j];
                bool num = true;
                if (sum < 2) {
                    num = false;
                }
                for (int k = 2; k * k <= sum; k++) {
                    if (sum % k == 0) {
                        num = false;
                        break;
                    }
                }
                if (num) {
                    mx = max(mx, c[j]);
                }
            }
        }
        c[i] = b[i] + mx;
        ans = max(ans, c[i]);
    }
    cout << ans;
}
