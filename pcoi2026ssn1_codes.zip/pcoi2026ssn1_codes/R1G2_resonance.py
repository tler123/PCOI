#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import sys

def solve():
    data = sys.stdin.read().split()
    if not data:
        return
    
    n = int(data[0])
    c = []
    p = []
    idx = 1
    for _ in range(n):
        c.append(int(data[idx]))
        p.append(int(data[idx+1]))
        idx += 2
        
    m = max(p) * 2 if p else 0
    f = [True] * (m + 1)
    f[0] = f[1] = False
    for i in range(2, int(m**0.5) + 1):
        if f[i]:
            for j in range(i * i, m + 1, i):
                f[j] = False

    dp = [0] * n
    for i in range(n):
        dp[i] = p[i]
        for j in range(i):
            if c[i] != c[j] and f[p[i] + p[j]]:
                dp[i] = max(dp[i], dp[j] + p[i])
                
    print(max(dp) if dp else 0)

if __name__ == '__main__':
    solve()

