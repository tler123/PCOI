#include <bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    
    long long int t; cin >> t;
    while (t--)
    {
        long long int a; cin >> a;
        vector<long long int> v(a, 0);
        for (long long int i = 0; i < a; i++)
        {
            cin >> v[i];
        }
        long long int ans = 0;
        for (long long int i = 0; i < a; i++)
        {
            long long int total = 0;
            for (long long int j = i + 1; j < a; j++)
            {
                if (v[i] == 0) break;
                if (v[j] == 0 or i == j) continue;
                if (v[i] == v[j])
                {
                    total++;
                    v[j] = 0;
                }
            }
            ans += (1 + total) * total / 2;
        }
        cout << ans << "\n";
    }
    return 0;
}
