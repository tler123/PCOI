#include<bits/stdc++.h>
using namespace std;
#define int long long
signed main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	string s;
	cin >> s;
	stack <int> st;
	pair<int,int> a[(int)s.size()+10] = {};
	int a1 = 0;
	for (int i = 0; i < (int)s.size(); i++)
	{
		if (s[i] == '(')
		{
			st.push(i+1);
		}
		else if (s[i] == ')')
		{
			a[++a1].first = st.top();
			st.pop();
			a[a1].second = i;
		}
	}
	for (int i = 1; i <= a1; i++)
	{
		reverse(s.begin()+a[i].first,s.begin()+a[i].second);
	}
	for (int i = 0; i < (int)s.size(); i++)
	{
		if (s[i] != '(' && s[i] != ')')
		{
			cout << s[i];
		}
	}
    return 0;
}
